package com.hsbc.dao;

import com.hsbc.model.Employee;

public interface EmployeeDao {
	
	public boolean employeeLoginValidate(Employee employee);
	

}
