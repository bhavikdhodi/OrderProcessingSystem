package com.hsbc.dao;

import com.hsbc.model.Customer;

public interface CustomerDao {
	
	public boolean customerLoginValidate(Customer customer);
	public Customer getCustomer(int customerId);

}
